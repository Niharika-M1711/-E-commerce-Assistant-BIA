# Customer FAQs (Sample Dataset)

This is a **sample dataset** for an e-commerce customer support assistant capstone.
Use this FAQ document as part of your knowledge base for RAG.

---

## 1. Orders & Tracking

**Q1.1: How do I place an order?**  
A: Browse products, add items to your cart, and proceed to checkout. You will be asked for your shipping address, contact details, and payment method before confirming the order.

**Q1.2: How can I track my order?**  
A: Once your order is shipped, we send you an email and SMS with a tracking link and tracking ID. You can also track your order from the “My Orders” section after logging in.

**Q1.3: Can I change my shipping address after placing an order?**  
A: Address changes are only possible before the order is shipped. If your order is still in “Processing” status, you can request an address change through support or your account dashboard.

**Q1.4: What are the different order statuses?**  
A: Common statuses include “Processing”, “Packed”, “Shipped”, “Out for Delivery”, “Delivered”, “Cancelled”, and “Returned”.

---

## 2. Shipping & Delivery

**Q2.1: What are the shipping charges?**  
A: Standard shipping is free for orders above ₹999. For orders below this value, a flat shipping fee of ₹79 is applied. Express shipping may have additional charges during checkout.

**Q2.2: How long does delivery take?**  
A: Standard delivery typically takes 3–6 business days depending on your location. Metro cities may receive orders sooner. Remote locations might take longer.

**Q2.3: Do you deliver to all locations?**  
A: We deliver to most pin codes across India. You can check serviceability by entering your pin code on the product page or during checkout.

**Q2.4: What if my order is delayed?**  
A: Delays can occur due to courier issues, weather conditions, or high volume. You can check the latest status via the tracking link or contact support for assistance.

---

## 3. Returns & Refunds

**Q3.1: What is your return policy?**  
A: Most items are eligible for return within 7 days of delivery if they are unused, in original condition, and with all accessories and packaging. Some items (e.g., hygiene products, software licenses) may not be returnable.

**Q3.2: How do I initiate a return?**  
A: Go to “My Orders”, select the relevant order, and click “Return/Replace”. Choose a reason and preferred resolution (refund or replacement). Our courier partner will schedule a pickup if the item is eligible.

**Q3.3: When will I receive my refund?**  
A: Once the returned item passes quality checks, refunds are processed within 3–7 business days depending on your payment method and bank.

**Q3.4: What if I receive a damaged or wrong product?**  
A: Initiate a return within 48 hours of delivery and upload clear photos of the issue. We will prioritise your replacement or refund.

---

## 4. Payments & Security

**Q4.1: What payment methods do you accept?**  
A: We accept credit cards, debit cards, net banking, UPI, popular wallets, and Cash on Delivery (COD) for eligible pin codes.

**Q4.2: Is it safe to pay online?**  
A: Yes. We use PCI-DSS compliant payment gateways and encryption. We do not store your full card details.

**Q4.3: My payment failed, but money was deducted. What should I do?**  
A: Failed payments are typically reversed by banks within 3–7 business days. If not credited back, share the transaction reference with support.

---

## 5. Cancellations

**Q5.1: Can I cancel my order?**  
A: Orders can be cancelled until shipped. Once shipped, cancellations are not possible; you may request a return after delivery if eligible.

---

## 6. Warranty & Support

**Q6.1: Do products come with a manufacturer warranty?**  
A: Most electronics come with a manufacturer warranty of 6–24 months. Details are on the product page and invoice.

**Q6.2: How can I contact customer support?**  
A: Email support@example.com or use chat support on the website.
