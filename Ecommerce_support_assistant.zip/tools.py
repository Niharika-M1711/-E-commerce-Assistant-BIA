"""
tools.py
Functions the assistant can call when a question needs real data instead of
document text — product specs, and order status.
"""

import json
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

with open(os.path.join(DATA_DIR, "Products.json"), encoding="utf-8") as f:
    PRODUCTS = json.load(f)

# Mock order database: order_id -> order info
MOCK_ORDERS = {
    "ORD1001": {"status": "Shipped", "eta": "2026-07-05", "items": ["Wireless Earbuds"]},
    "ORD1002": {"status": "Processing", "eta": "2026-07-08", "items": ["24-inch Monitor (Full HD)"]},
    "ORD1003": {"status": "Delivered", "eta": "2026-06-28", "items": ["65W GaN Charger"]},
}


def get_product_info(product_name: str) -> dict:
    """Find a product by (partial, case-insensitive) name match and return its full details."""
    product_name_lower = product_name.lower()
    for p in PRODUCTS:
        if product_name_lower in p["name"].lower():
            return p
    return {"error": f"No product found matching '{product_name}'"}


def get_order_status(order_id: str) -> dict:
    """Look up order status by order ID."""
    order = MOCK_ORDERS.get(order_id.upper())
    if not order:
        return {"error": f"No order found with ID '{order_id}'"}
    return {"order_id": order_id.upper(), **order}


# ---- Tool schemas for Groq function-calling ----
TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "get_product_info",
            "description": "Get details/specs/price/stock for a product by name. Use this for any question about a specific product's features, price, or availability.",
            "parameters": {
                "type": "object",
                "properties": {
                    "product_name": {
                        "type": "string",
                        "description": "The product name or a key part of it, e.g. 'monitor' or 'earbuds'",
                    }
                },
                "required": ["product_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_order_status",
            "description": "Get the current status of a customer's order using their order ID. Only call this if the customer has provided an order ID; otherwise ask them for it first.",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "The order ID, e.g. 'ORD1001'",
                    }
                },
                "required": ["order_id"],
            },
        },
    },
]

AVAILABLE_FUNCTIONS = {
    "get_product_info": get_product_info,
    "get_order_status": get_order_status,
}

KB_TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "search_knowledge_base",
        "description": "Search company FAQ and policy documents (shipping, returns, refunds, cancellations, payments, warranty, privacy, support contact). Use this for any general policy/how-to question that isn't about a specific product's specs or a specific order's status.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The customer's question, used to search the FAQ/policy documents.",
                }
            },
            "required": ["query"],
        },
    },
}


if __name__ == "__main__":
    print(get_product_info("monitor"))
    print(get_product_info("earbuds"))
    print(get_product_info("drone"))
    print(get_order_status("ord1001"))
    print(get_order_status("ORD9999"))